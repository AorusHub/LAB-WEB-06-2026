const menu = {
    lunabelle: { nama: "Lunabelle Pudding", harga: 23000 },
    lunabun: { nama: "Lunabun", harga: 19000 },
    moonberry: { nama: "Moonberry Sip", harga: 22000 },
    mallow: { nama: "Moonie Mallow Cheesecake", harga: 20000 },
    whispy: { nama: "Whispy Latte", harga: 19000 }
};

const ongkir = {
    reguler: 5000,
    ekspres: 15000
};

const btnTema = document.getElementById("btnTema");
const form = document.querySelector("form");
const inputNama = document.getElementById("nama");
const inputPesan = document.getElementById("pesan");
const hitungKarakter = document.getElementById("hitungKarakter");
const totalHarga = document.getElementById("totalHarga");
const pesanKonfirmasi = document.getElementById("pesanKonfirmasi");
const radioPengiriman = document.querySelectorAll('input[name="pengiriman"]');
const daftarKunci = Object.keys(menu); 

function formatRupiah(angka) {
    return `Rp ${angka.toLocaleString("id-ID")}`;
}

function ambilPesanan() {
    const pesanan = [];

    for (let key of daftarKunci) {
        const centang = document.getElementById(`menu-${key}`);
        const qty = parseInt(document.getElementById(`qty-${key}`).value);

        if (centang.checked) {
            pesanan.push({
                nama: menu[key].nama,
                jumlah: isNaN(qty) ? 0 : qty,
                subtotal: menu[key].harga * (isNaN(qty) ? 0 : qty)
            });
        }
    }
    return pesanan;
}

function hitungTotal() {
    const pesanan = ambilPesanan();
    if (pesanan.length === 0) {
        totalHarga.textContent = formatRupiah(0);
        return 0;
    }

    const metode = document.querySelector('input[name="pengiriman"]:checked').value;
    let total = ongkir[metode];
    pesanan.forEach((item) => {
        total += item.subtotal;
    });

    totalHarga.textContent = formatRupiah(total);
    return total;
}

function aturKolomJumlah() {
    for (let key of daftarKunci) {
        const centang = document.getElementById(`menu-${key}`);
        document.getElementById(`qty-${key}`).disabled = !centang.checked;
    }
}

btnTema.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");

    if (document.body.classList.contains("dark-mode")) {
        btnTema.textContent = "☀️ Mode Terang";
    } else {
        btnTema.textContent = "🌙 Mode Malam";
    }
});

for (let key of daftarKunci) {
    document.getElementById(`menu-${key}`).addEventListener("change", () => {
        aturKolomJumlah();
        hitungTotal();
    });
    document.getElementById(`qty-${key}`).addEventListener("input", hitungTotal);
}

radioPengiriman.forEach((radio) => {
    radio.addEventListener("change", hitungTotal);
});

inputPesan.addEventListener("input", (e) => {
    hitungKarakter.textContent = `${e.target.value.length}/100`;
});

form.addEventListener("submit", (e) => {
    e.preventDefault(); 

    const pesanan = ambilPesanan();

    if (pesanan.length === 0) {
        pesanKonfirmasi.className = "error";
        pesanKonfirmasi.textContent = "Pilih minimal satu menu dulu ya!";
        return;
    }

    const jumlahSalah = pesanan.some((item) => item.jumlah < 1);
    if (jumlahSalah) {
        pesanKonfirmasi.className = "error";
        pesanKonfirmasi.textContent = "Jumlah tiap menu minimal 1 ya!";
        return;
    }

    const metode = document.querySelector('input[name="pengiriman"]:checked').value;
    const total = hitungTotal();
    const ringkasan = pesanan.map((item) => `${item.jumlah} ${item.nama}`).join(", ");

    pesanKonfirmasi.className = "";
    pesanKonfirmasi.textContent =
        `Terima kasih, ${inputNama.value.trim()}! Pesanan kamu: ${ringkasan} ` +
        `(pengiriman ${metode}), total ${formatRupiah(total)}. 🌙`;

    form.reset();
    aturKolomJumlah();
    hitungKarakter.textContent = "0/100";
    hitungTotal();
});

aturKolomJumlah();
hitungTotal();
